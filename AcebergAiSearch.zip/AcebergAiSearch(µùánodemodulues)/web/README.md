# Arco Design Pro

## 快速开始

```
// 初始化项目
npm install

// 开发模式
npm run dev

// 构建
npm run build
