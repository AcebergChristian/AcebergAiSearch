const i18n = {
  'en-US': {
    'exception.result':
      'Developing, Please Stay Tuned!'
  },
  'zh-CN': {
    'exception.result': '开发中, 敬请期待',
  },
};

export default i18n;
