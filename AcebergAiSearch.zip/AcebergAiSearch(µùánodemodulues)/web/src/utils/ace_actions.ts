
// 定义 actions
export const setPath = (path) => ({
  type: 'SET_PATH',
  payload: path,
});

export const setKey = (key) => ({
  type: 'SET_KEY',
  payload: key,
});